// Info: ViewModel for creating, editing, and deleting prescriptions (admin).
import 'package:flutter/material.dart';

import '../../data/prescription_repository.dart';
import '../../domain/prescription.dart';
import '../../../authentication/data/account_session.dart';
import '../../../authentication/domain/session.dart';
import '../../../../utils/data/results.dart';

class PrescriptionModifyViewModel extends ChangeNotifier {
  //▫️Constructor
  PrescriptionModifyViewModel({
    required PrescriptionRepository prescriptionRepository,
    required AccountSession accountSession,
  })  : _prescriptionRepository = prescriptionRepository,
        _accountSession = accountSession;

  //▫️Variables
  final PrescriptionRepository _prescriptionRepository;
  final AccountSession _accountSession;

  bool _isLoading = false;
  String? _errorMessage;

  //▫️Getters
  bool get isLoading => _isLoading;
  String? get message => _errorMessage;

  //▫️Functions
  // Add a new prescription (admin only)
  Future<Result> addPrescription(Prescription prescription) async {
    final session = _accountSession.session;
    _errorMessage = null;

    if (session is! AdminSession) {
      _errorMessage = "Only admins are allowed to add prescriptions.";
      return Result.error(Exception(_errorMessage));
    }
    // Receptionist role cannot access prescription data
    if (session is AdminSession &&
        session.adminAccount.role == 'Receptionist') {
      _errorMessage =
          "Your access level does not allow managing prescription information.";
      return Result.error(Exception(_errorMessage));
    }

    _isLoading = true;
    notifyListeners();

    try {
      final result =
          await _prescriptionRepository.addPrescription(prescription);
      switch (result) {
        case Ok<Prescription>():
          debugPrint("Added prescription: ${result.value.id}");
        case Error<Prescription>():
          _errorMessage =
              "Unable to add prescription. Please try again or check your connection.";
          debugPrint("Failed to add prescription: ${result.error}");
      }
      return result;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  // Edit an existing prescription (admin only)
  Future<Result> editPrescription(Prescription prescription) async {
    final session = _accountSession.session;
    _errorMessage = null;

    if (session is! AdminSession) {
      _errorMessage = "Only admins are allowed to edit prescriptions.";
      return Result.error(Exception(_errorMessage));
    }
    // Receptionist role cannot access prescription data
    if (session is AdminSession &&
        session.adminAccount.role == 'Receptionist') {
      _errorMessage =
          "Your access level does not allow managing prescription information.";
      return Result.error(Exception(_errorMessage));
    }

    _isLoading = true;
    notifyListeners();

    try {
      final result =
          await _prescriptionRepository.editPrescription(prescription);
      switch (result) {
        case Ok<Prescription>():
          debugPrint("Edited prescription: ${result.value.id}");
        case Error<Prescription>():
          _errorMessage =
              "Unable to update prescription. Please try again or check your connection.";
          debugPrint("Failed to edit prescription: ${result.error}");
      }
      return result;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  // Delete a prescription (admin only)
  Future<Result> deletePrescription(int id) async {
    final session = _accountSession.session;
    _errorMessage = null;

    if (session is! AdminSession) {
      _errorMessage = "Only admins are allowed to delete prescriptions.";
      return Result.error(Exception(_errorMessage));
    }
    // Receptionist role cannot access prescription data
    if (session is AdminSession &&
        session.adminAccount.role == 'Receptionist') {
      _errorMessage =
          "Your access level does not allow managing prescription information.";
      return Result.error(Exception(_errorMessage));
    }

    _isLoading = true;
    notifyListeners();

    try {
      final result = await _prescriptionRepository.deletePrescription(id);
      switch (result) {
        case Ok<void>():
          debugPrint("Deleted prescription id: $id");
        case Error<void>():
          _errorMessage =
              "Unable to delete prescription. Please try again or check your connection.";
          debugPrint("Failed to delete prescription: ${result.error}");
      }
      return result;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }
}
