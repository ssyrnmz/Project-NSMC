import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:google_fonts/google_fonts.dart';

import '../viewmodels/hsp_modify_viewmodel.dart';
import '../viewmodels/hsp_view_viewmodel.dart';
import '../../domain/health_screening.dart';
import '../../domain/health_screening_validators.dart';
import '../../../../core/widgets/loading_screen.dart';
import '../../../../utils/data/results.dart';
import '../../../../utils/ui/show_snackbar.dart';
import '../../../../utils/ui/show_success_dialogue.dart';
import '../../../../utils/ui/input_formatters.dart';

class HealthScreeningAddDetailScreen extends StatefulWidget {
  const HealthScreeningAddDetailScreen({super.key});

  @override
  State<HealthScreeningAddDetailScreen> createState() =>
      _HealthScreeningAddDetailScreenState();
}

class _HealthScreeningAddDetailScreenState
    extends State<HealthScreeningAddDetailScreen> {
  //▫️Variables:
  final _formKey = GlobalKey<FormState>(); // Form key

  // Form Inputs:
  late TextEditingController _nameController;
  late TextEditingController _priceController;
  late TextEditingController _descriptionController;
  late List<TextEditingController> _includedController;
  File? _image;

  //▫️State initialization & disposal:
  @override
  void initState() {
    super.initState();
    _nameController = TextEditingController();
    _priceController = TextEditingController();
    _descriptionController = TextEditingController();
    _includedController = [
      TextEditingController(),
    ]; // start with one included point
  }

  @override
  void dispose() {
    _nameController.dispose();
    _priceController.dispose();
    _descriptionController.dispose();
    for (final i in _includedController) {
      i.dispose;
    }
    super.dispose();
  }

  //▫️Main UI:
  @override
  Widget build(BuildContext context) {
    final vmModify = context.watch<HealthScreeningModifyViewModel>();
    final vmData = context.read<HealthScreeningViewModel>();

    return LoadingOverlay(
      isLoading: vmModify.isLoading,
      child: Scaffold(
        backgroundColor: const Color(0xFFFFFFFF),
        appBar: AppBar(
          backgroundColor: const Color(0xFFf9fafb),
          elevation: 0,
          surfaceTintColor: const Color.fromARGB(255, 200, 200, 200),
          centerTitle: true,
          leading: IconButton(
            icon: const Icon(
              Icons.arrow_back_ios_new,
              color: Color(0xFF4D7C4A),
            ),
            onPressed: () => Navigator.pop(context),
          ),
          title: Text(
            'Add Health Package',
            style: GoogleFonts.poppins(
              color: const Color(0xFF1E1E1E),
              fontSize: 20,
              fontWeight: FontWeight.w600,
            ),
          ),
          bottom: PreferredSize(
            preferredSize: const Size.fromHeight(1),
            child: Container(color: const Color(0xFFE6E6E6), height: 1),
          ),
        ),
        body: Form(
          key: _formKey,
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 16),

                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: buildImageField(
                    onTap: () async {
                      // Button's function to upload image file of package
                      final result = await vmModify.pickImage();

                      if (!context.mounted) return;

                      switch (result) {
                        case Ok<File?>():
                          final image = result.value;
                          late final String message;

                          // File picked or cancelled
                          if (image != null) {
                            setState(() {
                              _image = image;
                            });
                            message = "Image file successfully picked.";
                          } else {
                            message = "No file was picked.";
                          }

                          showSnackBar(context: context, text: message);
                        case Error<File?>():
                          showSnackBar(
                            context: context,
                            text:
                                vmModify.message ??
                                "An unknown error occured. Please try again.",
                            color: Colors.red[900],
                          );
                      }
                    },
                    cache: _image, // Picture
                  ),
                ),
                const SizedBox(height: 16),

                // Package Details section
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 20,
                    vertical: 12,
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      buildTextField(
                        label: 'Package Title',
                        controller: _nameController,
                        hintText: "Enter package title",
                        validator: (value) =>
                            HealthScreeningValidators.isNameValid(value),
                        inputFormatter: [InputFormat.noLeadingWhitespace],
                      ),
                      const SizedBox(height: 12),

                      buildTextField(
                        label: "Price",
                        controller: _priceController,
                        hintText: "Enter price (e.g: 199.99)",
                        validator: (value) =>
                            HealthScreeningValidators.isPriceValid(value),
                        inputFormatter: [
                          FilteringTextInputFormatter.allow(
                            RegExp(r'^\d*\.?\d{0,2}'),
                          ),
                        ],
                        keyboardType: const TextInputType.numberWithOptions(
                          decimal: true,
                        ),
                      ),
                      const SizedBox(height: 12),

                      buildTextField(
                        label: "Description",
                        controller: _descriptionController,
                        hintText: "Enter package description",
                        maxLines: 4,
                        validator: (value) =>
                            HealthScreeningValidators.isDescriptionValid(value),
                      ),
                    ],
                  ),
                ),

                // Included Package section
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 20,
                    vertical: 12,
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "What's Included",
                        style: GoogleFonts.poppins(
                          fontSize: 18,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      const SizedBox(height: 12),
                      Column(
                        children: [
                          for (int i = 0; i < _includedController.length; i++)
                            Padding(
                              padding: const EdgeInsets.only(bottom: 10),
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const Icon(
                                    Icons.check_circle_rounded,
                                    color: Color(0xFF6FCF97),
                                    size: 20,
                                  ),
                                  const SizedBox(width: 10),
                                  Expanded(
                                    child: buildTextField(
                                      label: "",
                                      controller: _includedController[i],
                                      hintText: "Enter included item",
                                      validator: (value) =>
                                          HealthScreeningValidators.isIncludedValid(
                                            value,
                                          ),
                                      inputFormatter: [
                                        InputFormat.noLeadingWhitespace,
                                      ],
                                    ),
                                  ),
                                  IconButton(
                                    icon: const Icon(
                                      Icons.close,
                                      size: 20,
                                      color: Colors.red,
                                    ),
                                    onPressed: () {
                                      if (_includedController.length > 1) {
                                        setState(
                                          () => _includedController.removeAt(i),
                                        );
                                      }
                                    },
                                  ),
                                ],
                              ),
                            ),
                          TextButton.icon(
                            onPressed: () {
                              setState(
                                () => _includedController.add(
                                  TextEditingController(),
                                ),
                              );
                            },
                            icon: const Icon(Icons.add),
                            label: const Text("Add point"),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 30),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: SizedBox(
                    width: double.infinity,
                    child: Center(
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF6FBF73),
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(
                            horizontal: 100,
                            vertical: 16,
                          ),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8),
                          ),
                          elevation: 4,
                        ),
                        onPressed: () async {
                          // Button's function to create new health screening package
                          if (_formKey.currentState!.validate() &&
                              _image != null &&
                              _includedController.isNotEmpty) {
                            // Health screening details
                            final saveData = HealthScreening(
                              id: 0,
                              name: _nameController.text.trim(),
                              price:
                                  double.parse(_priceController.text.trim()) *
                                  100,
                              description: _descriptionController.text.trim(),
                              included: _includedController
                                  .map((items) => items.text.trim())
                                  .toList(),
                              image: '',
                              archived: false,
                              updatedAt: DateTime.timestamp(),
                            );

                            final result = await vmModify.addPackage(
                              saveData,
                              _image!,
                            );

                            if (!context.mounted) return;

                            switch (result) {
                              case Ok():
                                showSuccessDialog(
                                  context: context,
                                  title:
                                      "New Health Screening Package Created!",
                                  message:
                                      "The ${saveData.name}'s details has been successfully added.",
                                  onButtonPressed: () {
                                    vmData.load();

                                    Navigator.of(context).popUntil((route) {
                                      return route.settings.name ==
                                              '/packageModifyList' ||
                                          route.isFirst;
                                    });
                                  },
                                );

                              case Error():
                                showSnackBar(
                                  context: context,
                                  text:
                                      vmModify.message ??
                                      "An unknown error occured. Please try again.",
                                  color: Colors.red[900],
                                );
                            }
                          } else {
                            showSnackBar(
                              context: context,
                              text:
                                  "Your submission is unfinished or invalid, Please check and try again.",
                              color: Colors.red[900],
                            );
                          }
                        },

                        child: Text(
                          'Save Changes',
                          style: GoogleFonts.poppins(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 50),
              ],
            ),
          ),
        ),
      ),
    );
  }

  //▫️Helper Widget:
  // Image Field
  Widget buildImageField({
    required void Function()? onTap,
    required File? cache,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Stack(
        children: [
          Container(
            width: double.infinity,
            height: 220,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: const Color(0xFF6FBF73), width: 2),
              image: DecorationImage(
                image: (cache == null)
                    ? const AssetImage('assets/images/si.png')
                    : FileImage(cache) as ImageProvider,
                fit: BoxFit.cover,
              ),
            ),
          ),
          Positioned(
            top: 8,
            right: 8,
            child: Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.9),
                shape: BoxShape.circle,
              ),
              child: const Icon(Icons.edit, size: 20, color: Color(0xFF6FBF73)),
            ),
          ),
        ],
      ),
    );
  }

  // Stylized text field
  Widget buildTextField({
    required String label,
    required TextEditingController controller,
    int maxLines = 1,
    String? hintText,
    TextInputType keyboardType = TextInputType.text,
    String? Function(String?)? validator,
    List<TextInputFormatter>? inputFormatter,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: GoogleFonts.poppins(
            color: Colors.black,
            fontSize: 15.5,
            fontWeight: FontWeight.w500,
          ),
        ),

        const SizedBox(height: 6),

        Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 15),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: const Color(0xFFE0E0E0)),
          ),
          child: TextFormField(
            controller: controller,
            maxLines: maxLines,
            keyboardType: keyboardType,
            validator: validator,
            inputFormatters: inputFormatter,
            style: const TextStyle(color: Colors.black, fontSize: 15),
            decoration: InputDecoration(
              hintText: hintText,
              hintStyle: TextStyle(color: Colors.grey[600], fontSize: 15),
              border: InputBorder.none,
              isDense: true,
              contentPadding: EdgeInsets.zero,
            ),
          ),
        ),
      ],
    );
  }
}
